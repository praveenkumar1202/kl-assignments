# from fastapi import FastAPI
from pydantic import BaseModel
from pymongo import MongoClient

client = MongoClient("mongodb://intern_23:intern%40123@192.168.0.220:2717/interns_b2_23")
database = client['interns_b2_23']
Book = database['praveen_kumar']
# app = FastAPI()


class Library(BaseModel):
    id: int
    name: str
    author: str
    quantity: int


storage = []


async def store_book(book: Library):
    db = client.interns_b2_23
    book_instance = db.praveen_kumar
    book_instance.insert_one(book.dict())
    #storage.append(book)
    return {"message": "Book stored successfully"}


def get_book(book_name: str):
    return {"error": "Book not found"}


def update_book(book_name: str, new_book: Library):
    for index, existing_book in enumerate(storage):
        if existing_book.name == book_name:
            storage[index] = new_book
            return {"message": "Book updated successfully"}
    return {"error": "Book not found"}


def delete_book(book_name: str):
    for index, book in enumerate(storage):
        if book.name == book_name:
            storage.pop(index)
            return {"message": "Book deleted successfully"}
    return {"error": "Book not found"}
