from pydantic import BaseModel


class Library(BaseModel):
    id: int
    title: str
    author: str
    quantity: int
